import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-twb',
  templateUrl: './twb.component.html',
  styles: []
})
export class TwbComponent implements OnInit {

  myName: String = "Vijay";

  constructor() { }

  ngOnInit() {
  }

}
