export interface Contact {
    name : string
    phone: number
    email: string
}
